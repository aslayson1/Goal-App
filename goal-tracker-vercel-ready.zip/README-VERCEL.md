# Vercel Deployment Notes

This project is configured for Next.js (App Router) and Tailwind CSS v4.

## Deploy on Vercel

1. Push this folder to a Git repo (GitHub/GitLab).
2. On Vercel, **Import Project** → select the repo.
3. Set **Framework Preset** to **Next.js** (detected automatically).
4. Ensure **Node.js** runtime is >= 18.18 (Project Settings → General).
5. No env vars are required unless your features need them.
6. Vercel will run `pnpm install` and `pnpm build` automatically.

If you see pnpm lockfile warnings, we've pinned `packageManager: pnpm@10.0.0` and added a `vercel.json` that installs without a frozen lockfile.
